
#!/usr/bin/env python
# encoding: utf-8

import tweepy #https://github.com/tweepy/tweepy
import csv



#Twitter API credentials
consumer_key = "Qw2fK1exCOxY4ANRK02bl8Xbe"
consumer_secret = "fXr1HFiUolrMGdcEjhNarkxxmVJyogaIp9w8VWDDGJVDv7x0zp"
access_key = "125876989-ZbvS93wBZReU0JCgRzFvAth4x4PARblXOCaRfHv7"
access_secret = "aiPwgjh7nn0DMDylEchtXmYvjsJtih1f33bpztlGGDbrp"

handles_list = ["oliviataters", "netflix_bot", "DearAssistant", "predartbot", "a_quilt_bot", "reverseocr", "MuseumBot", "pentametron", "accidental575", "JustToSayBot", "FavThingsBot", "portmanteau_bot", "BloombrgNewsish", "AwlTags", "big_ben_clock", "AutoCharts", "SandyAid", "loudbot", "thebookfinder2", "nintendoartbot", "thinkpiecebot", "lilCryptoBot", "deepquestionbot", "tinycarebot", "beckettbot", "Procrastibot", "i_find_planets", "thegodbot", "itsJesusCristo", "horse_ebooks", "AndyMcMahonBot", "jadntrumpebooks", "harshavatrx", "niccageplotbot", "art_critic_bot", "aceattorneybot", "everysheriff", "itsspeltcaesar", "winelover_bot", "camptownladies", "pentametron", "theMemesBot", "securitynewsbot", "tweetbotv1", "nice_tips_bot", "MarksFakeFacts", "RobotzRule", "hackernewsbot", "garry12gg", "AllsortsBot"]

def get_all_tweets(screen_name, writer):
    auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_key, access_secret)
    api = tweepy.API(auth)

    recenttweets = []
    new_tweets = api.user_timeline(screen_name = handle, count=100)
    recenttweets.extend(new_tweets)

    global label


#save the id of the oldest tweet less one
    oldest = recenttweets[-1].id - 1

    #keep grabbing tweets until there are no tweets left to grab
    while len(recenttweets) < 100:
        print("getting tweets before %s" % (oldest))

        #all subsiquent requests use the max_id param to prevent duplicates
        new_tweets = api.user_timeline(screen_name = handle,count=100,max_id=oldest)

        #save most recent tweets
        recenttweets.extend(new_tweets)

        #update the id of the oldest tweet less one
        oldest = recenttweets[-1].id - 1

        print("...%s tweets downloaded so far" % (len(recenttweets)))

    #transform the tweepy tweets into a 2D array that will populate the csv
    Resultingtweets= [[tweet.id_str, tweet.user.screen_name, tweet.favorite_count, tweet.retweet_count, tweet.created_at, tweet.text.encode("utf-8"), 1] for tweet in recenttweets]
    print("Account: %s" % handle)
    if(label == 0):
        writer.writerow(["Tweet_id","Twitter_Account","Favourite_Count","Retweet_Count","Tweet_created_at","Tweet_text", "LABEL"])
        label = 1

    writer.writerows(Resultingtweets)

if __name__ == '__main__':
    label = 0
    with open('all_50_bot_tweets.csv', 'w', encoding='utf-8') as f_all:
        writer = csv.writer(f_all)

        for handle in handles_list:
            get_all_tweets("handles", writer)
            print ("Done.")
