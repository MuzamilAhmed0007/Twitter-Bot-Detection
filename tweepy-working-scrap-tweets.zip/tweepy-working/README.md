Tweepy: Twitter tweets scraper in Python!
======

[![Build Status](http://img.shields.io/travis/tweepy/tweepy/master.svg?style=flat)](https://travis-ci.org/tweepy/tweepy)
[![Documentation Status](http://img.shields.io/badge/docs-v3.6.0-brightgreen.svg?style=flat)](http://docs.tweepy.org)
[![Version](http://img.shields.io/pypi/v/tweepy.svg?style=flat)](https://crate.io/packages/tweepy)
[![Coverage Status](https://img.shields.io/coveralls/tweepy/tweepy/master.svg?style=flat)](https://coveralls.io/r/tweepy/tweepy?branch=master)
[![Discord](https://img.shields.io/discord/432685901596852224.svg)](https://discord.gg/bJvqnhg)

Installation
------------
The easiest way to install the latest version
is by using pip/easy_install to pull it from PyPI:

    pip install tweepy

You may also use Git to clone the repository from
GitHub and install it manually:

    git clone https://github.com/tweepy/tweepy.git
    cd tweepy
    python setup.py install

Python 2.7, 3.4, 3.5 & 3.6 are supported.

Community
---------
- [Discord Chat](https://discord.gg/bJvqnhg)


Scrap Bot Tweets(/scrap_tweets_bot.py)
---------
/scrap_tweets_bot.py is the code file to scrap twitter bots user tweets. It contains the the list of bots on which code runs and iterate on each user to scrap 100 bot user tweets.Output will be a csv file named 'all_50_bot_tweets.csv'


Scrap Human Tweets(/scrap_tweets_human.py)
---------
/scrap_tweets_human.py is the code file to scrap twitter human user tweets. It contains the the list of 50 human accounts on which code runs and iterate on each user to scrap 100 human user tweets.Output will be a csv file named 'all_50_human_tweets.csv'


